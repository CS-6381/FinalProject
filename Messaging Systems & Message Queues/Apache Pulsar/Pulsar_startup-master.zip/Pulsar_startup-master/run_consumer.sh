bin/pulsar-client consume my-topic -s "first-subscription"
