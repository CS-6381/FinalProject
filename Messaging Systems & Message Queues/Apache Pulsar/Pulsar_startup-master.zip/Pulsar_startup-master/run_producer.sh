bin/pulsar-client produce my-topic --messages "hello-pulsar"
